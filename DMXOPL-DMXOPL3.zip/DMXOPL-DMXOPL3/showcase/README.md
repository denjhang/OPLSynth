# Examples

These mp3 files are included specifically to demonstrate DMXOPL v1.7
No copyright infringement was/is intended.

MP3 files are ~128 kbps for size and fair use reasons.

*Note:* Mother 3 - Fun Naming.mp3 uses a dev build of DMXOPL from August 03, 2017.
